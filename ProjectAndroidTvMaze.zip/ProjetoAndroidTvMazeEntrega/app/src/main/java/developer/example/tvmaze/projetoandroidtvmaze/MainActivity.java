package developer.example.tvmaze.projetoandroidtvmaze;

import android.Manifest;
import android.support.annotation.NonNull;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v4.app.ActivityCompat;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class MainActivity extends AppCompatActivity implements RecyclerView.OnItemTouchListener {

    private android.support.v7.widget.SearchView searchBar;
    private Button favouritesButton;
    private final static int REQUEST_CODE_ASK_PERMISSIONS = 1;
    private static final String[] REQUIRED_SDK_PERMISSIONS = new String[] {
            Manifest.permission.INTERNET, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE };

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        checkPermissions();
        setContentView(R.layout.activity_main);

        searchBar = findViewById(R.id.searchBar);

        searchBar.setOnQueryTextListener(new android.support.v7.widget.SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                String userSearch = query.toLowerCase();
                new HttpClient(MainActivity.this, "http://api.tvmaze.com/search/shows?q="+userSearch, new EventType().getSEARCH_SERIES()).execute();
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                String userSearch = newText.toLowerCase();

                new HttpClient(MainActivity.this, "http://api.tvmaze.com/search/shows?q="+userSearch, new EventType().getSEARCH_SERIES()).execute();
                return true;
            }
        });

        searchBar.setOnCloseListener(new android.support.v7.widget.SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                new HttpClient(MainActivity.this,"http://api.tvmaze.com/shows?page=1", new EventType().getSHOW_SERIES()).execute();
                return true;
            }
        });

//        searchBar.setOnQueryTextFocusChangeListener(new View.OnFocusChangeListener() {
//            @Override
//            public void onFocusChange(View view, boolean b) {
//                new HttpClient(MainActivity.this,"http://api.tvmaze.com/shows?page=1", new EventType().getSHOW_SERIES()).execute();
//            }
//        });

        favouritesButton = findViewById(R.id.favouritesButton);
        favouritesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Favoritos.class);
                startActivity(intent);
            }
        });

        new HttpClient(this,"http://api.tvmaze.com/shows?page=1", new EventType().getSHOW_SERIES()).execute();
    }


    protected void checkPermissions() {
        final List<String> missingPermissions = new ArrayList<>();
        // check all required dynamic permissions
        for (final String permission : REQUIRED_SDK_PERMISSIONS) {
            final int result = ContextCompat.checkSelfPermission(this, permission);
            if (result != PackageManager.PERMISSION_GRANTED) {
                missingPermissions.add(permission);
            }
        }
        if (!missingPermissions.isEmpty()) {
            // request all missing permissions
            final String[] permissions = missingPermissions
                    .toArray(new String[missingPermissions.size()]);
            ActivityCompat.requestPermissions(this, permissions, REQUEST_CODE_ASK_PERMISSIONS);
        } else {
            final int[] grantResults = new int[REQUIRED_SDK_PERMISSIONS.length];
            Arrays.fill(grantResults, PackageManager.PERMISSION_GRANTED);
            onRequestPermissionsResult(REQUEST_CODE_ASK_PERMISSIONS, REQUIRED_SDK_PERMISSIONS,
                    grantResults);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[],
                                           @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE_ASK_PERMISSIONS:
                for (int index = permissions.length - 1; index >= 0; --index) {
                    if (grantResults[index] != PackageManager.PERMISSION_GRANTED) {
                        // exit the app if one permission is not granted
                        Toast.makeText(this, "Required permission '" + permissions[index]
                                + "' not granted, exiting", Toast.LENGTH_LONG).show();
                        finish();
                        return;
                    }
                }
                // all permissions were granted
                break;
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void recebeSeries(HttpResponse event) {

        final RecyclerView recyclerView = findViewById(R.id.rvSeries);

        final RecyclerView.LayoutManager listLayoutManager = new LinearLayoutManager(this,
                LinearLayoutManager.VERTICAL, false);

        switch(event.getEventType()) {

            case "SHOW_SERIES":
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<Series>>(){}.getType();
                List<Series> yourClassList = gson.fromJson(event.getJsonResponse(),listType);
                ArrayList<Series> listaSeries = (ArrayList) yourClassList;

                recyclerView.setAdapter(new RecyclerAdapter(listaSeries));

                recyclerView.setLayoutManager(listLayoutManager);
                break;

            case "SEARCH_SERIES":

                JsonArray jsonArray = new Gson().fromJson(event.getJsonResponse(), JsonArray.class);
                Gson gsonPesquisa = new Gson();
                ArrayList<Series> arrayList = new ArrayList<Series>();
                for (JsonElement element: jsonArray) {
                    Series tmpSerie = gsonPesquisa.fromJson(element.getAsJsonObject().get("show").toString(), Series.class);
                    arrayList.add(tmpSerie);
                }

                recyclerView.setAdapter(new RecyclerAdapter(arrayList));

                recyclerView.setLayoutManager(listLayoutManager);
                break;
        }

    }

    @Override
    public void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override
    public void onStop() {
        EventBus.getDefault().unregister(this);
        super.onStop();
    }

    @Override
    public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {
        return false;
    }

    @Override
    public void onTouchEvent(RecyclerView rv, MotionEvent e) {

    }

    @Override
    public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

    }
}
