package developer.example.tvmaze.projetoandroidtvmaze;

public class HttpResponse {

    private String jsonResponse;
    private String eventType;

    public HttpResponse(String jsonResponse, String eventType) {
        this.jsonResponse = jsonResponse;
        this.eventType = eventType;
    }

    public String getJsonResponse() {
        return jsonResponse;
    }

    public void setJsonResponse(String jsonResponse) {
        this.jsonResponse = jsonResponse;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }
}
