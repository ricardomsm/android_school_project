package developer.example.tvmaze.projetoandroidtvmaze;

import android.content.Context;
import android.os.AsyncTask;

import org.greenrobot.eventbus.EventBus;

import java.io.IOException;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public  class HttpClient extends AsyncTask<String, Void, Void> {

    private Context context;
    private String url;
    private String eventType;

    public HttpClient(Context context, String url, String eventType) {
        this.context = context;
        this.url = url;
        this.eventType = eventType;
    }

    @Override
    protected Void doInBackground(String... params) {
        try {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(url)
                    .build();
            Response response = client.newCall(request).execute();
            EventBus.getDefault().post(new HttpResponse(response.body().string(), eventType));
        } catch (IOException e) {
        }

        return null;
    }
}

