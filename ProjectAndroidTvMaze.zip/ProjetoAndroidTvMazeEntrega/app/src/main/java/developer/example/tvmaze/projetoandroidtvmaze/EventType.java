package developer.example.tvmaze.projetoandroidtvmaze;

public class EventType {

    private final String SHOW_SERIES = "SHOW_SERIES";
    private final String SEARCH_SERIES = "SEARCH_SERIES";

    public String getSHOW_SERIES() {
        return SHOW_SERIES;
    }

    public String getSEARCH_SERIES() {
        return SEARCH_SERIES;
    }
}
