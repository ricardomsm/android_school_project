package developer.example.tvmaze.projetoandroidtvmaze;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;


import org.parceler.Parcels;

import java.util.ArrayList;

public class Favoritos extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.favoritos);

        // TODO - https://github.com/google/gson/blob/master/UserGuide.md
        // TODO - https://github.com/chennaione/sugar


//        Series serieFavoritada = Parcels.unwrap(getIntent().getParcelableExtra("serieFavoritada"));
////        ArrayList<Series> seriesFavoritadas = new ArrayList<>();
////        seriesFavoritadas.add(serieFavoritada);
////
////        RecyclerView recyclerView = findViewById(R.id.rvSeriesFavoritos);
////
////        recyclerView.setAdapter(new RecyclerAdapter(seriesFavoritadas));
////
////        RecyclerView.LayoutManager listLayoutManager = new LinearLayoutManager(this,
////                LinearLayoutManager.VERTICAL, false);
////
////        recyclerView.setLayoutManager(listLayoutManager);
    }
}
