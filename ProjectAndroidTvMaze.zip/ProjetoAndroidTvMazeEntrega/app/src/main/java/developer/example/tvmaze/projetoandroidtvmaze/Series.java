package developer.example.tvmaze.projetoandroidtvmaze;

import com.google.gson.annotations.SerializedName;

import org.greenrobot.greendao.annotation.Convert;
import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.converter.PropertyConverter;
import org.parceler.Parcel;
import org.parceler.ParcelConstructor;

import java.util.Arrays;

@Parcel(Parcel.Serialization.BEAN)
public class Series {

    // TODO - https://stackoverflow.com/questions/23069799/parsing-a-string-id-with-sugarorm-and-gson/35602175#35602175

    private long id;
    @SerializedName("url")
    private String urlSerie;
    private String name;
    private String language;
    private String[] genres;
    private String status;
    private String premiered;
    private String officialSite;
    private int runtime;
    private Rating rating;
    @SerializedName("image")
//    @Convert(converter = Imagens.ImageConverter.class, columnType = String.class)
    private Imagens image;
    private String summary;

    public Series() {

    }

    @ParcelConstructor
    public Series(long id, String urlSerie, String name, String language, String[] genres, String status, String premiered, String officialSite, int runtime, Rating rating, Imagens image, String summary) {
        this.id = id;
        this.urlSerie = urlSerie;
        this.name = name;
        this.language = language;
        this.genres = genres;
        this.status = status;
        this.premiered = premiered;
        this.officialSite = officialSite;
        this.runtime = runtime;
        this.rating = rating;
        this.image = image;
        this.summary = summary;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUrlSerie() {
        return urlSerie;
    }

    public void setUrlSerie(String urlSerie) {
        this.urlSerie = urlSerie;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String[] getGenres() {
        return genres;
    }

    public void setGenres(String[] genres) {
        this.genres = genres;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPremiered() {
        return premiered;
    }

    public void setPremiered(String premiered) {
        this.premiered = premiered;
    }

    public String getOfficialSite() {
        return officialSite;
    }

    public void setOfficialSite(String officialSite) {
        this.officialSite = officialSite;
    }

    public int getRuntime() {
        return runtime;
    }

    public void setRuntime(int runtime) {
        this.runtime = runtime;
    }

    public Rating getRating() {
        return rating;
    }

    public void setRating(Rating rating) {
        this.rating = rating;
    }

    public Imagens getImage() {
        return image;
    }

    public void setImage(Imagens image) {
        this.image = image;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    @Override
    public String toString() {
        return "Series{" +
                ", urlSerie='" + urlSerie + '\'' +
                ", name='" + name + '\'' +
                ", language='" + language + '\'' +
                ", genres=" + Arrays.toString(genres) +
                ", status='" + status + '\'' +
                ", premiered=" + premiered +
                ", officialSite='" + officialSite + '\'' +
                ", runtime=" + runtime +
                ", rating=" + rating +
                '}';
    }

    @Parcel(Parcel.Serialization.BEAN)
    public static class Rating {

        private Float average;

        public Rating() {

        }

        @ParcelConstructor
        public Rating(Float average) {
            this.average = average;
        }

        public Float getAverage() {
            return average;
        }

        public void setAverage(Float average) {
            this.average = average;
        }
    }

    @Parcel(Parcel.Serialization.BEAN)
    public static class Imagens {

        private String medium;
        private String original;

        public Imagens() {

        }

        @ParcelConstructor
        public Imagens(String medium, String original) {
            this.medium = medium;
            this.original = original;
        }

        public String getMedium() {
            return medium;
        }

        public void setMedium(String medium) {
            this.medium = medium;
        }

        public String getOriginal() {
            return original;
        }

        public void setOriginal(String original) {
            this.original = original;
        }


//        @Entity
//        public static class ImageConverter implements PropertyConverter<Imagens, String> {
//
//            @Override
//            public Imagens convertToEntityProperty(String databaseValue) {
//
//                if (databaseValue != null) {
//                    String[] images = databaseValue.split(";");
//                    return new Imagens(images[0], images[1]);
//                }
//
//                return null;
//            }
//
//            @Override
//            public String convertToDatabaseValue(Imagens entityProperty) {
//                return entityProperty.medium + ";" + entityProperty.original;
//            }
//        }
    }
}
