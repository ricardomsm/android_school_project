package developer.example.tvmaze.projetoandroidtvmaze;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.parceler.Parcels;

import java.io.Serializable;
import java.util.ArrayList;

public class RecyclerAdapter extends RecyclerView.Adapter<MyViewHolder> {

    private ArrayList<Series> series;

    public RecyclerAdapter(ArrayList<Series> series){
        this.series = series;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, int position) {
        final Series serie = series.get(position);

        if (serie.getImage()==null || serie.getImage().getMedium()==null) {
         Picasso.get().load(R.drawable.cancel).into(holder.getMediumCover());
        } else {
            Picasso.get().load(serie.getImage().getMedium()).into(holder.getMediumCover());
        }
        holder.getSerieButton().setText(serie.getName());
        holder.getSerieButton().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Context serieContext = v.getContext();
                Intent intent = new Intent(serieContext, SerieDetalhes.class);

                Bundle serieBundle = new Bundle();
                serieBundle.putParcelable("serie", Parcels.wrap(serie));
                intent.putExtras(serieBundle);

                serieContext.startActivity(intent);

            }
        });
    }

    @Override
    public int getItemCount() {
        return series.size();
    }

}
