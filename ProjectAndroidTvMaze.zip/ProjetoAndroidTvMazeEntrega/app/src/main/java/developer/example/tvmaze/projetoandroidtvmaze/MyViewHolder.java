package developer.example.tvmaze.projetoandroidtvmaze;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MyViewHolder extends RecyclerView.ViewHolder {

    private ImageView mediumCover;
    private Button serieButton;

    public MyViewHolder(View itemView) {
        super(itemView);
        serieButton = itemView.findViewById(R.id.serieButton);
        mediumCover = itemView.findViewById(R.id.mediumCover);
    }

    public ImageView getMediumCover() {
        return mediumCover;
    }

    public void setMediumCover(ImageView mediumCover) {
        this.mediumCover = mediumCover;
    }

    public Button getSerieButton() {
        return serieButton;
    }

    public void setSerieButton(Button serieButton) {
        this.serieButton = serieButton;
    }
}
