package developer.example.tvmaze.projetoandroidtvmaze;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.squareup.picasso.Picasso;

import org.parceler.Parcels;

public class SerieDetalhes extends AppCompatActivity {

    private ImageView serieCover;
    private TextView summarySerie;
    private TextView languageSerie;
    private TextView genresSerie;
    private TextView statusSerie;
    private TextView runtimeSerie;
    private TextView premieredSerie;
    private TextView officialSiteSerie;
    private TextView ratingSerie;
    private ToggleButton favouritesToggle;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.serie_detalhes);

        serieCover = findViewById(R.id.serieCover);
        summarySerie = findViewById(R.id.summarySerie);
        languageSerie = findViewById(R.id.languageSerie);
        genresSerie = findViewById(R.id.genresSerie);
        statusSerie = findViewById(R.id.statusSerie);
        runtimeSerie = findViewById(R.id.runtimeSerie);
        premieredSerie = findViewById(R.id.premieredSerie);
        officialSiteSerie = findViewById(R.id.officialSiteSerie);
        ratingSerie = findViewById(R.id.ratingSerie);


        final Series serieDetalhada = Parcels.unwrap(getIntent().getParcelableExtra("serie"));


        if (serieDetalhada.getImage()==null || serieDetalhada.getImage().getOriginal() == null) {
            Picasso.get().load(R.drawable.no_cover).into(serieCover);
        } else {
            Picasso.get().load(serieDetalhada.getImage().getOriginal()).into(serieCover);
        }

        if (serieDetalhada.getSummary()==null) {
            summarySerie.setText("Sumário não disponível");
        } else {
            summarySerie.setText(Html.fromHtml(serieDetalhada.getSummary()));
        }

        languageSerie.setText("Language: "+serieDetalhada.getLanguage());

        StringBuilder sb = new StringBuilder();
        for (String genre:serieDetalhada.getGenres()) {
            sb.append(genre).append(",");
        }

        if (sb.length()==0) {
            genresSerie.setText("Genres não disponíveis");
        } else {
            genresSerie.setText("Genres: "+sb.substring(0,sb.lastIndexOf(",")));
        }

        statusSerie.setText("Status: "+serieDetalhada.getStatus());
        runtimeSerie.setText("Runtime: "+String.valueOf(serieDetalhada.getRuntime()) + " min");

        if (serieDetalhada.getPremiered()==null) {
            premieredSerie.setText("Sem data de estreia disponível.");
        } else {
            premieredSerie.setText("Premiered: "+serieDetalhada.getPremiered().substring(0,serieDetalhada.getPremiered().indexOf("-")));
        }


        if (serieDetalhada.getOfficialSite()==null) {
            officialSiteSerie.setText("Site não disponível");
        } else {
            officialSiteSerie.setText(serieDetalhada.getOfficialSite());
        }

        if (serieDetalhada.getRating().getAverage()==null) {
            ratingSerie.setText("Ainda não foi avaliada ou rating indisponível");
        } else {
            ratingSerie.setText("Rating: "+String.valueOf(serieDetalhada.getRating().getAverage())+"/10");
        }

        favouritesToggle = findViewById(R.id.favouritesToggle);
        favouritesToggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {

                if (b) {

                    Toast.makeText(SerieDetalhes.this, "Adicionada aos favoritos", Toast.LENGTH_SHORT).show();

                } else {

                    Toast.makeText(SerieDetalhes.this, "Removida dos favoritos", Toast.LENGTH_SHORT).show();

                }
            }
        });
    }
}
